document.addEventListener('DOMContentLoaded', function() {
    // Initialize the map
    const map = L.map('map').setView([37.8, -96], 4);


    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // determine marker size based on magnitude
    function getRadius(magnitude) {
        return Math.max(magnitude * 4, 5); // Minimum size of 5
    }

    // get color based on depth
    function getColor(depth) {
        if (depth > 90) {
            return '#800026';
        } else if (depth > 70) {
            return '#BD0026';
        } else if (depth > 50) {
            return '#E31A1C';
        } else if (depth > 30) {
            return '#FC4E2A';
        } else if (depth > 10) {
            return '#FD8D3C';
        } else {
            return '#FFEDA0';
        }
    }

    // Function to create popup content
    function createPopupContent(feature) {
        return `
            <h3>Location: ${feature.properties.place}</h3>
            <hr>
            <p><strong>Magnitude:</strong> ${feature.properties.mag}</p>
            <p><strong>Depth:</strong> ${feature.geometry.coordinates[2]} km</p>
            <p><strong>Time:</strong> ${new Date(feature.properties.time).toLocaleString()}</p>
        `;
    }

    // add the legend to the map
    function addLegend(map) {
        const legend = L.control({position: 'bottomright'});
        legend.onAdd = function (map) {
            const div = L.DomUtil.create('div', 'info legend');
            const depths = [-10, 10, 30, 50, 70, 90];
            let labels = ['<strong class="legend-title">Depth (km)</strong>'];

            for (let i = 0; i < depths.length; i++) {
                labels.push(
                    '<i style="background:' + getColor(depths[i] + 1) + '"></i> ' +
                    depths[i] + (depths[i + 1] ? '&ndash;' + depths[i + 1] : '+')
                );
            }

            div.innerHTML = labels.join('<br>');
            return div;
        };
        legend.addTo(map);
    }

    // Fetch earthquake data
    fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson')
        .then(response => response.json())
        .then(data => {
          
            L.geoJSON(data, {
                pointToLayer: function (feature, latlng) {
                    return L.circleMarker(latlng, {
                        radius: getRadius(feature.properties.mag),
                        fillColor: getColor(feature.geometry.coordinates[2]),
                        color: "#000",
                        weight: 1,
                        opacity: 1,
                        fillOpacity: 0.8
                    });
                },
                onEachFeature: function (feature, layer) {
                    layer.bindPopup(createPopupContent(feature));
                }
            }).addTo(map);

            // Add legend 
            addLegend(map);

            
            document.getElementById('loading').style.display = 'none';
        })
        .catch(error => {
            console.error('Error fetching earthquake data:', error);
            document.getElementById('loading').textContent = 'Error loading earthquake data. Please try again later.';
        });
});